import java.util.*;

class ArraySumOfPair{
	
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the elements in the array : ");
		int n = sc.nextInt();
		
		int array[] = new int[6];
		System.out.println("Enter the elements of the array : ");
		for(int i = 0; i < array.length; i++){
			
			array[i] = sc.nextInt();
			
		}
		
		System.out.println("Enter the sum you want : ");
		int sum = sc.nextInt();
		
		for(int i = 0; i < array.length; i++){
			for(int j = i+1; j < array.length; j++){
				
				
			}
			
		}
		
	}
}